import 'package:flutter_test/flutter_test.dart';
import 'package:science_world/lib/features/library/data/book_repository.dart';
import 'package:science_world/lib/features/library/data/book_model.dart';

void main() {
  final repo = BookRepository();

  test('fetchBooks returns empty list when no books', () async {
    final books = await repo.fetchBooks(grade: 'الصف التاسع', subject: 'اللغة العربية');
    expect(books, isA<List<BookModel>>());
    expect(books.isEmpty, true);
  });

  test('downloadBook throws exception if fileUrl is empty', () async {
    final book = BookModel(
      id: 'test',
      title: 'اختبار',
      grade: 'الصف التاسع',
      subject: 'العلوم',
      year: '2026–2027',
      publisher: 'وزارة التربية',
      fileUrl: '',
      fileSize: 0,
      fileType: 'application/pdf',
      lastChecked: DateTime.now(),
      isAvailable: false,
      rights: '',
    );
    expect(() async => await repo.downloadBook(book), throwsException);
  });
}
