import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الصفحة الرئيسية')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('مرحبًا بك في عالم العلوم', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('اختر صفك للبدء. المحتوى (الدروس، الكتب، الأسئلة) قيد التطوير.'),
            const SizedBox(height: 24),
            ElevatedButton(onPressed: () => context.go('/grades'), child: const Text('اختيار الصف')),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: () => context.go('/settings'), child: const Text('الإعدادات')),
          ],
        ),
      ),
    );
  }
}