import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class ActivationCodePage extends StatelessWidget {
  const ActivationCodePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدخال كود التفعيل')),
      body: const Center(child: Text('إدخال كود التفعيل سيظهر هنا')),
    );
  }
}
