import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class StudentProgressPage extends StatelessWidget {
  const StudentProgressPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('التقدم الدراسي')),
      body: const Center(child: Text('معلومات التقدم ستظهر هنا')),
    );
  }
}
