import 'package:flutter/material.dart';
import '../../data/question_service.dart';
import '../question_detail_page.dart';

class QuestionListPage extends StatefulWidget {
  const QuestionListPage({super.key});
  @override
  State<QuestionListPage> createState() => _QuestionListPageState();
}

class _QuestionListPageState extends State<QuestionListPage> {
  late final QuestionService _service;
  List<QuestionModel> _questions = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _service = QuestionService();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() => _loading = true);
    try {
      final qs = await _service.getQuestions();
      setState(() {
        _questions = qs;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('أسئلة')),
        actions: [IconButton(onPressed: _fetch, icon: const Icon(Icons.refresh))],
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : _questions.isEmpty
                  ? const Center(child: Text('لا توجد أسئلة.'))
                  : ListView.separated(
                      itemCount: _questions.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, index) {
                        final q = _questions[index];
                        return ListTile(
                          title: Text(q.title, textAlign: TextAlign.right),
                          subtitle:
                              Text('${q.subject} – ${q.grade}', textAlign: TextAlign.right),
                          trailing:
                              q.isPaid ? const Icon(Icons.lock) : null,
                          onTap: () => Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) => QuestionDetailPage(questionId: q.id),
                          )),
                        );
                      },
                    ),
    );
  }
}
