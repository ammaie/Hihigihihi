import 'package:flutter/material.dart';
import '../../data/question_service.dart';

class QuestionDetailPage extends StatefulWidget {
  final String questionId;
  const QuestionDetailPage({required this.questionId, super.key});
  @override
  State<QuestionDetailPage> createState() => _QuestionDetailPageState();
}
