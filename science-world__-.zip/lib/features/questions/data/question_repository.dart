import 'package:supabase_flutter/supabase_flutter.dart';
import '../model/question_model.dart';

class QuestionRepository {
  final SupabaseClient _client;

  QuestionRepository({SupabaseClient? client}) : _client = client ?? Supabase.instance.client;

  Future<List<QuestionModel>> fetchAll({
    String? grade,
    String? subject,
    bool onlyFree = true,
    String? type,
    String? difficulty,
    int limit = 100,
  }) async {
    final query = _client.from('questions').select().limit(limit);
    if (grade != null) query.eq('grade', grade);
    if (subject != null) query.eq('subject', subject);
    if (type != null) query.eq('type', type);
    if (difficulty != null) query.eq('difficulty', difficulty);
    if (onlyFree) query.eq('is_paid', false);
    final response = await query.order('created_at', ascending: false);
    if (response.error != null) {
      throw Exception('Error fetching questions: ${response.error!.message}');
    }
    final data = response.data as List<dynamic>;
    return data.map((e) => QuestionModel.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<QuestionModel> fetchById(String id) async {
    final response = await _client
        .from('questions')
        .select()
        .eq('id', id)
        .single();
    if (response.error != null) {
      throw Exception('Error fetching question: ${response.error!.message}');
    }
    return QuestionModel.fromJson(response.data as Map<String, dynamic>);
  }

  Future<void> upsert(QuestionModel question) async {
    final data = question.toJson();
    final response = await _client.from('questions').upsert([data]).select();
    if (response.error != null) {
      throw Exception('Error upserting question: ${response.error!.message}');
    }
  }
}
