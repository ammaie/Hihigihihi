import 'package:equatable/equatable.dart';

/// Represents a single question in the Science World question bank.
class QuestionModel extends Equatable {
  /// Unique identifier for the question.
  final String id;

  /// Grade level (e.g., "الصف التاسع").
  final String grade;

  /// Subject (e.g., "الرياضيات").
  final String subject;

  /// Chapter within the subject.
  final String? chapter;

  /// Lesson within the chapter.
  final String? lesson;

  /// School year (e.g., "2026–2027").
  final String? schoolYear;

  /// Difficulty level.
  final String? difficulty;

  /// Type of the question (e.g., "اختيار من متعدد").
  final String type;

  /// Source of the question (official exam, textbook, internal, AI).
  final String source;

  /// Status of review (draft, review, approved).
  final String reviewStatus;

  /// Whether the question is paid content.
  final bool isPaid;

  /// Correct answer – can be a string, number, or structured JSON.
  final String correctAnswer;

  /// Explanation or solution steps.
  final String solution;

  /// Date and time when the question was created.
  final DateTime createdAt;

  /// Date and time when the question was last updated.
  final DateTime updatedAt;

  const QuestionModel({
    required this.id,
    required this.grade,
    required this.subject,
    this.chapter,
    this.lesson,
    this.schoolYear,
    this.difficulty,
    required this.type,
    required this.source,
    required this.reviewStatus,
    required this.isPaid,
    required this.correctAnswer,
    required this.solution,
    required this.createdAt,
    required this.updatedAt,
  });

  /// Create an instance from JSON returned by Supabase.
  factory QuestionModel.fromJson(Map<String, dynamic> json) {
    return QuestionModel(
      id: json['id'] as String,
      grade: json['grade'] as String,
      subject: json['subject'] as String,
      chapter: json['chapter'] as String?,
      lesson: json['lesson'] as String?,
      schoolYear: json['school_year'] as String?,
      difficulty: json['difficulty'] as String?,
      type: json['type'] as String,
      source: json['source'] as String,
      reviewStatus: json['review_status'] as String,
      isPaid: json['is_paid'] == true,
      correctAnswer: json['correct_answer'] as String,
      solution: json['solution'] as String,
      createdAt:
          DateTime.parse(json['created_at'] as String? ?? DateTime.now().toIso8601String()),
      updatedAt:
          DateTime.parse(json['updated_at'] as String? ?? DateTime.now().toIso8601String()),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'grade': grade,
      'subject': subject,
      'chapter': chapter,
      'lesson': lesson,
      'school_year': schoolYear,
      'difficulty': difficulty,
      'type': type,
      'source': source,
      'review_status': reviewStatus,
      'is_paid': isPaid,
      'correct_answer': correctAnswer,
      'solution': solution,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  @override
  List<Object?> get props => [
    id,
    grade,
    subject,
    chapter,
    lesson,
    schoolYear,
    difficulty,
    type,
    source,
    reviewStatus,
    isPaid,
    correctAnswer,
    solution,
    createdAt,
    updatedAt,
  ];
}
