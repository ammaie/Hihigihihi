import '../model/question_model.dart';
import '../repository/question_repository.dart';

/// Service layer for questions.
/// It exposes high‑level operations that the UI can call.
class QuestionService {
  final QuestionRepository _repo;

  QuestionService({QuestionRepository? repository})
      : _repo = repository ?? QuestionRepository();

  /// Fetch questions with optional filters.
  Future<List<QuestionModel>> getQuestions({
    String? grade,
    String? subject,
    String? type,
    String? difficulty,
    bool onlyFree = true,
  }) async {
    return await _repo.fetchAll(
      grade: grade,
      subject: subject,
      type: type,
      difficulty: difficulty,
      onlyFree: onlyFree,
    );
  }

  /// Retrieve a single question by id.
  Future<QuestionModel> getById(String id) async {
    return await _repo.fetchById(id);
  }

  /// Add or update a question.
  Future<void> upsert(QuestionModel question) async {
    await _repo.upsert(question);
  }
}
