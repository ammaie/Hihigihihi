import 'package:flutter/material.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        children: const [
          ListTile(leading: Icon(Icons.text_fields), title: Text('حجم الخط'), subtitle: Text('افتراضي')),
          ListTile(leading: Icon(Icons.language), title: Text('اللغة'), subtitle: Text('العربية')),
          ListTile(leading: Icon(Icons.info_outline), title: Text('حول التطبيق'), subtitle: Text('عالم العلوم v1.0')),
        ],
      ),
    );
  }
}